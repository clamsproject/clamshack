"""

Analyze the raw whisper output and create an HTML file with observations
on segment-vs-words mismatches.

Usage:

$ python whisper.py WHISPER_OUTPUT_FILE HTML_FILE

"""

import sys, json, collections


Segment = collections.namedtuple(
    'Segment', ['id', 'start', 'end','text', 'words', 'mismatch'])

Words = collections.namedtuple(
    'Words', ['start', 'end', 'text'])


def glom(words):
    glommed = ''
    for word in words:
        if word[0].isdigit() or word[0].isalpha():
            glommed += ' '
        glommed += word
    return glommed.strip()

def read_segments(output: dict) -> dict:
    """Return a dictionary indexed on seek identifiers where each value is a list
    of segments for the seek."""
    data = collections.defaultdict(list)
    for segment in output['segments']:
        identifier = segment["id"]
        seek = segment['seek']
        text = segment['text']
        segment_start = segment["start"]
        segment_end = segment["end"]
        normalized_text = text.lower().strip() 
        words = [w['word'].strip() for w in segment['words']]
        normalized_words = [w.lower() for w in words]
        normalized_words_text = glom(normalized_words)
        words_tuple = None
        if words:
            words_start = segment['words'][0]['start']
            words_end = segment['words'][-1]['end']
            words_tuple = Words(words_start, words_end, normalized_words_text)
        mismatch =  True if normalized_text != normalized_words_text else False
        segment_tuple = Segment(
            identifier,segment_start, segment_end,
            normalized_text, words_tuple, mismatch)
        data[seek].append(segment_tuple)
    return data

def flatten(xss: list) -> list:
    return [x for xs in xss for x in xs]

def get_mismatches(data: dict) -> list:
    return [s for s in flatten(data.values()) if s.mismatch]

def get_seeks_with_mismatches(data: dict) -> list:
    result = set()
    for seek in sorted(data):
        for segment in data[seek]:
            if segment.mismatch:
                result.add(seek)
    return list(sorted(result))

def get_time_in_mismatches(mismatches: list) -> int:
    return int(sum([s.end - s.start for s in mismatches]))

def get_time_in_seeks_with_mismatches(data):
    seeks = get_seeks_with_mismatches(data)
    total_time = 0
    for seek in seeks:
        segments = data[seek]
        total_time += segments[-1].end - segments[0].start
    return int(total_time)

def write_html(data, segments, whisper_analysis):
    with open(whisper_analysis, 'w') as fh:
        fh.write(f'<h3>{whisper_output_file}</h3>\n\n')
        html_start(fh)
        html_stats(fh, data, segments)
        html_table(fh)
        html_spacer(fh)
        for position in sorted(data):
            duration = round(data[position][-1].end - data[position][0].start)
            length = len(data[position])
            fh.write(f'<tr id={position}>\n')
            fh.write(f'  <td colspan=6>{position} &mdash; {duration} seconds, {length} segments</td>')
            fh.write('</tr>\n')
            for segment in data[position]:
                tr_class = ' class=mismatch' if segment .mismatch else ''
                fh.write(f'<tr{tr_class}>\n')
                html_td(fh, '&nbsp;' * 6, segment.id, 'text',
                    f'{segment.start:.2f}', f'{segment.end:.2f}', segment.text)
                fh.write('</tr>\n')
                fh.write(f'<tr{tr_class}>\n')
                if segment.words is None:
                    html_td(fh, '&nbsp;', '&nbsp;', 'words', '-', '-', '')
                else:
                    fh.write(f'<tr{tr_class}>\n')
                    words = segment.words
                    html_td(fh, '&nbsp;', '&nbsp;', 'words',
                        f'{words.start:.2f}', f'{words.end:.2f}', words.text)
                fh.write('</tr>\n')
            html_spacer(fh)
        fh.write('</table>\n\n</body>\n\n</html>\n')

def html_stats(fh, data, segments):
    mismatches = get_mismatches(data)
    time_in_mismatches = get_time_in_mismatches(mismatches)
    seeks_with_mismatches = get_seeks_with_mismatches(data)
    html_table(fh)
    html_trs(fh,
        ('Segments with mismatches', f'{len(mismatches)}/{len(segments)}'),
        ('Seeks with mismatches', f'{len(seeks_with_mismatches)}/{len(data)}'),
        ('Cumulative time in mismatches', f'{time_in_mismatches} seconds'),
        ('Cumulative time in seeks with mismatches', 
            f'{get_time_in_seeks_with_mismatches(data)} seconds'))
    fh.write('</table>\n\n<p/>\n\n')
    if seeks_with_mismatches:
        first_seek = seeks_with_mismatches[0]
        fh.write(f'[ <a href=#{first_seek}>{first_seek}</a>\n')
        for seek in seeks_with_mismatches[1:]:
            fh.write(f'| <a href=#{seek}>{seek}</a>\n')
        fh.write(']\n\n<p/>\n\n')

def html_start(fh):
    fh.write('<html>\n\n<head>\n')
    fh.write('<meta charset="UTF-8">\n')
    fh.write('<style>\n')
    fh.write('.mismatch { color: red; }\n')
    fh.write('.emphasis { font-weight: bold; }\n')
    fh.write('.spacer { background: #eee; }\n')
    fh.write('</style>\n</head>\n\n<body>\n\n')

def html_table(fh):
    fh.write('<table border=1 cellspacing=0 cellpadding=5>\n')

def html_trs(fh, *rows):
    for row in rows:
        fh.write('<tr>\n')
        html_td(fh, *row)
        fh.write('</tr>\n')

def html_td(fh, *cells):
    for cell in cells:
        fh.write(f'  <td>{cell}</td>\n')

def html_spacer(fh):
    fh.write('<tr class=spacer>\n')
    fh.write(f'  <td colspan=6></td>\n')
    fh.write('</tr>\n')



if __name__ == '__main__':

    if len(sys.argv) == 3:
        whisper_output_file = sys.argv[1]
        whisper_analysis = sys.argv[2]
        print(f'{whisper_output_file} --> {whisper_analysis}')
    else:
        exit('Usage: python whisper.py <infile> <outfile>')
    whisper_output = json.loads(open(whisper_output_file).read())
    data = read_segments(whisper_output)
    write_html(data, whisper_output['segments'], whisper_analysis)
