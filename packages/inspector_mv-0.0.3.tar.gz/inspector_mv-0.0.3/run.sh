# Use the first three for index, views and timeframes
# Use the first for captions
# Use the second for the transcript
# Use the third for correlations
# Use the fourth for named entities

rm -rf x ; python run_inspector.py -i out/summaries/summaries/cpb-aacip-225-12z34w2c.json -o x
rm -rf x ; python run_inspector.py -i out/summaries/summaries/cpb-aacip-507-028pc2tq55.json -o x
rm -rf x ; python run_inspector.py -i out/summaries/summaries/cpb-aacip-526-z60bv7c69m.json -o x
rm -rf x ; python run_inspector.py -i examples/pipelines/spacy-v1.1/cpb-aacip-507-9882j68s35-transcript.json -o x
