# (generated with --quick)

CAPTIONS_PAGE: str
CORRELATIONS_PAGE: str
CSS_PAGE: str
ENTITIES_PAGE: str
INDEX_PAGE: str
JS_PAGE: str
TIMEFRAMES_PAGE: str
TRANSCRIPT_PAGE: str
VIEWS_PAGE: str
a_right: str
a_top: str
a_topleft: str
hide: str
